<!-- page-example START -->
<h1>Example page</h1>
<? include __DIR__ . "/templates/sasscat_example.php"; ?>
<? include __DIR__ . "/templates/sasscat_example2.php"; ?>
<!-- page-example END -->