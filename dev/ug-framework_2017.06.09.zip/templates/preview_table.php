<table>
    <caption>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iste, porro.</caption>
    <thead>
    <tr>
        <th>Lorem ipsum.</th>
        <th>Eligendi, nihil!</th>
        <th>Vel, vitae!</th>
        <th>Aspernatur, consequatur.</th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <th>Lorem ipsum dolor sit.</th>
        <td>Ad ducimus quo reiciendis!</td>
        <td>Dolorum nobis pariatur placeat.</td>
        <td>Aspernatur corporis error libero.</td>
    </tr>
    <tr>
        <th>Lorem ipsum dolor sit.</th>
        <td>Consectetur ipsa reiciendis sunt.</td>
        <td>Autem explicabo quod unde?</td>
        <td>Beatae blanditiis dolorem perferendis?</td>
    </tr>
    <tr>
        <th>Lorem ipsum dolor sit.</th>
        <td>Accusamus illo obcaecati quidem.</td>
        <td>Ad enim est nulla.</td>
        <td>Amet commodi dolor fuga.</td>
    </tr>
    <tr>
        <th>Lorem ipsum dolor sit.</th>
        <td>Consequuntur ex inventore ipsum!</td>
        <td>A cupiditate id quis?</td>
        <td>Aperiam quisquam ratione velit?</td>
    </tr>
    </tbody>
    <tfoot>
    <tr>
        <th>Lorem ipsum dolor.</th>
        <td>Lorem ipsum dolor sit amet.</td>
        <td>Ad esse harum quam sit.</td>
        <td>Corporis maiores minima nostrum ut.</td>
    </tr>
    </tfoot>
</table>