<?php
/**
 * @param string $var['content']
 * @param array $var['data'] - data for example_data2 tpl
 */
?>
<!-- sasscat_example START -->
<div class="class" style="margin-bottom: 1em; border: 1px solid #f00;">
    <p><?=variable($var['content']); ?></p>
    <?=render('sasscat_example2',variable($var['data'])); ?>
</div>
<!-- sasscat_example END -->