<?php
/**
 * @param
 */
$sasscat_example2_def = array(
);
if(!empty($sasscat_example2)){
    $sasscat_example2 = array_merge($sasscat_example2_def,$sasscat_example2);
}else{
    $sasscat_example2 = $sasscat_example2_def;
}
?>
<!-- sasscat_example2 START -->

<!-- sasscat_example2 END -->
<?php
if(!empty($sasscat_exampl2e)) {
    $sasscat_example2 = $sasscat_example2_def;
}
?>