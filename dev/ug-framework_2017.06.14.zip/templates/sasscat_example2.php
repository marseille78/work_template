<?php
/**
 * @param string $var['content']
 */
?>
<!-- sasscat_example2 START -->
<span class="class2" style="border: 1px solid #0f0; margin-bottom: 1em; display: block;">
    <p><?=variable($var['content']); ?></p>
</span>
<!-- sasscat_example2 END -->