<!-- page-example START -->
<h1>Example page</h1>
<?=render("type_example"); ?>
<!-- page-example END -->