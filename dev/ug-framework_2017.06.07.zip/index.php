<?
ini_set('error_reporting', E_ALL);

$path = '';
if($_GET['compile']==1){
    chmod(__DIR__.'/html/',777);
    $dirs = scandir('./');
    foreach ($dirs as $dir) {
        if($dir == '.' || $dir == '..' || !preg_match('/page\-(.*)\.php/',$dir,$page)) continue;
        $html = file_get_contents($_SERVER['SCRIPT_URI'].'?page='.$page[1].'&compile=2');
        file_put_contents(__DIR__.'/html/page-'.$page[1].'.html',$html);
    }
}else if($_GET['compile']==2){
    $path = '../';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <link rel="stylesheet" href="css/css.css" />

    <script src="js/js.js"></script>
</head>
<body>
        <?
        include "page-".$_GET['page'].".php";
        ?>
</body>
</html>